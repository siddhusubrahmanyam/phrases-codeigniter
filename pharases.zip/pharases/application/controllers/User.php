<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL & ~E_NOTICE);

class User extends CI_Controller {

 	public function __construct() {
	      parent::__construct();
	      $this->load->model('Common_Model');   
	      date_default_timezone_set('Asia/Kolkata');
	}

	public function index() {
		//print_r("xrctfvgybhunjmk"); exit;


	$this->form_validation->set_rules('email', 'Email','required|valid_email|is_unique[user.emailid]');
	$this->form_validation->set_rules('phone', 'phone','required|regex_match[/^[0-9]{10}$/]|is_unique[user.phone]');
			$data = $this->input->post();
			$firstname = $data["firstname"];
			$lastname = $data["lastname"];
			$email = $data["email"];
			$phone = $data["phone"];
			$password = $data["password"];
			$gender = $data["gender"];
			$dob = $data["dob"];
			$pob = $data["pob"];
		if($this->form_validation->run()) {
           if($data['gender'] == 'male') {
                $management = "male";
            } elseif ($data['gender'] == 'female') {
                $management = "female";
            }
			$insert = array(
				"firstname" => $firstname,
				"lastname" => $lastname,
				"emailid" => $email,
				"phone" =>$phone,
				"password" => $password,
				"gender" => $management,
				"dob" => $dob,
				"pob" =>$pob,
				"status" => 1
			);

			//print_r($insert); exit;

			if($this->Common_Model->insertdata("user", $insert) == 1) {
				$message = array(
	                'status' => 0,
	                'msg' => 'Added new user',
	            );
			} else {
				$message = array(
	                'status' => 1,
	                'msg' => 'There is an error while inserting',
	            );
			}
		} else {
			$message = array(
                'status' => 1,
                'msg' => 'This email is already existed',
            );
		}
		
		echo json_encode($message);
	}
   //$valid_plan_name = $this->form_validation->required($plan_name);
	public function login() {
		//$this->form_validation->set_rules('email', 'Email', 'required');
		//$this->form_validation->set_rules('password', 'Password', 'required');
		
			$data = $this->input->post();
			if((isset($data['email'])&& $data['email']!='') || (isset($data['password'])&& $data['password']!='') ||(isset($data['phone'])&& $data['phone']!='')){
			$email = $data["email"];
			$password = $data["password"];
			$phone = $data["phone"];
			$valid_email = $this->form_validation->required($email);
			$valid_password = $this->form_validation->required($password);
			$valid_phone = $this->form_validation->required($phone);
			if($valid_email == 1 && $valid_password == 1 ){
             if($this->Common_Model->isexist("user", array("emailid" => $email)) == 1) {
				$data = $this->Common_Model->fetchwhere("user", "", array("emailid" => $email), "", "row");
				if($data->password == $password) {
					$message = array(
		                'status' => 0,
		                'msg' => 'Welcome to....',
		            );
				} elseif($data->password != $password ) {
					$message = array(
		                'status' => 1,
		                'msg' => 'Wrong password',
		            );
				}
				
		}else {
			$message = array(
                'status' => 1,
                'msg' => 'This email is not valid'
            );
            //echo $message;exit;
			}

			}
			elseif($valid_phone == 1 && $valid_password == 1 ){
				if($this->Common_Model->isexist("user", array("phone" => $phone)) == 1) {
				$data = $this->Common_Model->fetchwhere("user", "", array("phone" => $phone), "", "row");
				if($data->password == $password) {
					$message = array(
		                'status' => 0,
		                'msg' => 'Welcome to....',
		            );
				} elseif($data->password != $password) {
					$message = array(
		                'status' => 1,
		                'msg' => 'Wrong password',
		            );
				}

			
			}
			else{
				$message = array(
                'status' => 1,
                'msg' => 'This phone is not valid',
            );
				//echo $message;exit;
		}

			}
			else{
               $message = array(
		                'status' => 1,
		                'msg' => 'All Fields are required',
		            );
			}
			// if($this->Common_Model->isexist("user", array("emailid" => $email)) == 1) {
			// 	$data = $this->Common_Model->fetchwhere("user", "", array("emailid" => $email), "", "row");
			// 	if($data->password == $password) {
			// 		$message = array(
		 //                'status' => 0,
		 //                'msg' => 'Welcome to....',
		 //            );
			// 	} else {
			// 		$message = array(
		 //                'status' => 1,
		 //                'msg' => 'Wrong password',
		 //            );
			// 	}
			// }

			//  else {
			// 	$message = array(
	  //               'status' => 1,
	  //               'msg' => 'This user is not existed',
	  //           );
			// }
				echo json_encode($message);
	}
}

// public function(){
// 	$data = $this->input->post();
// }
}
