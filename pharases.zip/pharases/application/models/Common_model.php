    <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_Model extends CI_Model {

    /**
     * Fetch values in any table
     * ----------------------------
     * @param: {string}   Table name
     * @param: {string}   column alies
     * @param: {array}    And conditions list
     * @param: {array}    Or conditions list
     * @param: {string}   Resposnse type i.e. result_array or row_array
     * ----------------------------
     * @return: {array}   return response
     */
    public function fetchwhere($tbl_name,$columnAlies="",$andwherecondition="",$orwherecondition="",$type=""
    ) {
    	if ( $columnAlies != "" ) {
            $this->db->select($columnAlies);
    	} else {
    		$this->db->select('*');
    	}
        
        $this->db->from($tbl_name);
        if($andwherecondition!=''){
            foreach($andwherecondition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        if($orwherecondition!=''){
            foreach($orwherecondition as $key=>$value){
                $this->db->or_where($key, $value);
            }
        }
        //$this->db->order_by("property","asc");
        $query = $this->db->get();
        if ($query->num_rows()>0) {
            if ($type == 'row_array') {
                return $query->row_array();
            } else if ($type == 'row') {
                return $query->row();
            } else {
                return $query->result_array();
            }
        } else {
            return false;
        }
    }

    

    /**
     * Insert value in any table
     * ----------------------------
     * @param: {string}   Table name
     * @param: {array}    Values
     * ----------------------------
     * @return: {boolean} is inserted status
     */
    public function insertdata($tbl_name,$value){
        if($this->db->insert($tbl_name, $value)){
            return true;
        }else{
            return false;
        }
    }

    public function getvalue($tbl_name,$cond,$field){
        
        $this->db->select('*');
        $this->db->from($tbl_name);
        $this->db->where('id', $cond);
        
        $query = $this->db->get();
        $result = $query->row_array();
        return $result[$field];
        
    }

    /**
     * Update value in any table
     * ----------------------------
     * @param: {string}   Table name
     * @param: {array}    Values
     * @param: {array}    update conditions
     * ----------------------------
     * @return: {boolean}  true
     */
    public function updatedata($tbl_name,$values,$condition=""){
        if($condition!=''){
            foreach($condition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        $this->db->update($tbl_name ,$values);
        return true;
    }

    /**
     * Delete value in any table
     * ----------------------------
     * @param: {string}   Table name
     * @param: {array}    delete conditions
     * ----------------------------
     * @return: {boolean}  true
     */
    public function deletedata($tbl_name,$condition=""){
        if($condition!=''){
            foreach($condition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        $this->db->delete($tbl_name);
        return true;
    }

    /**
     * Check value is exists or not in any table
     * ----------------------------
     * @param: {string}   Table name
     * @param: {array}    Condition for checking value in DB
     * ----------------------------
     * @return: {boolean} is exist status
     */
	public function isexist($table,$condition){
	    $this->db->select('*');
	    $this->db->from($table);
	    $this->db->where($condition);
	    $query = $this->db->get();
	    
	    if($query->num_rows() > 0){
	        return true;
	    }else{
	        return false;
	    }
	}

    public function exist($table,$condition){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($condition);
        $query = $this->db->get();
        
        if($query->num_rows() > 0){
            return false;
        }else{
            return true;
        }
    }

    /**
     * Send mail with the help of the PHPMailer Library
     * ----------------------------
     * @param: {string}   subject of email
     * @param: {string}   body of email
     * @param: {string}   to email
     * ----------------------------
     * @return: {mixed}   response
     */
    public function sendMail($subject, $body, $to) {
        $this->load->library('email');
        $from = 'support@estatemaximum.com';
        
        $result = $this->email
            ->from($from)
            ->reply_to($from)    // Optional, an account where a human being reads.
            ->to($to)
            ->subject($subject)
            ->message($body)
            ->send();
        //var_dump($result);
        //echo $this->email->print_debugger();
        return $result;
    }

    public function sendSms($mobile,$message){
        $smsMessage = urlencode($message);
        $url = "http://sms99.co.in/pushsms.php?username=tr7real&password=vFPEHl&sender=svnrel&message=".$smsMessage."&numbers=".$mobile;
        $postData = array(
            'authkey' => '88276AGwzewOEdFs559d2888',
            'mobiles' => $mobile,
            'message' => $smsMessage,
            'sender' => 'ANHIVE',
        );
        
        $ch = curl_init($url);
        
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        
        if (curl_errno($ch)) {
            echo 'error:' . curl_error($ch);
        }
        
        curl_close($ch);
        return true;
    }

    public function insertUser($table, $data) {
       $this->db->insert($table, $data);
       return $this->db->insert_id();
    }

    public function currentDate() {
        return date('Y-m-d H:i:s');
    }
}